import { useState } from "react";
import { Link } from "react-router-dom";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { api } from "../api/client";
import { fmtConf } from "../format";
import { CLASS_COLORS, type FirewallRule } from "../types";

interface Hover {
  rule: FirewallRule;
  x: number;
  y: number;
}

export default function FirewallPage() {
  const qc = useQueryClient();
  const rules = useQuery({ queryKey: ["firewall"], queryFn: api.firewallRules });
  const [hover, setHover] = useState<Hover | null>(null);
  const [expanded, setExpanded] = useState<string | null>(null);
  const [confirming, setConfirming] = useState<string | null>(null);

  const del = useMutation({
    mutationFn: api.deleteRule,
    onSuccess: () => {
      setConfirming(null);
      qc.invalidateQueries({ queryKey: ["firewall"] });
    },
  });

  const clearAll = useMutation({
    mutationFn: api.clearRules,
    onSuccess: () => qc.invalidateQueries({ queryKey: ["firewall"] }),
  });

  const list = rules.data?.rules ?? [];

  return (
    <>
      <div style={{ display: "flex", alignItems: "center", gap: 14, marginBottom: 8 }}>
        <h1 style={{ fontSize: 22 }}>방화벽 차단 목록</h1>
        <span className="muted" style={{ fontSize: 13 }}>
          {list.length}개 규칙 (firewall.json 동기화)
        </span>
        {list.length > 0 && (
          <button
            className="btn danger"
            style={{ marginLeft: "auto" }}
            disabled={clearAll.isPending}
            onClick={() => {
              if (confirm(`차단 규칙 ${list.length}건을 전체 삭제할까요?`)) clearAll.mutate();
            }}
          >
            {clearAll.isPending ? "삭제 중…" : "전체 삭제"}
          </button>
        )}
      </div>
      <p className="muted" style={{ marginBottom: 22, fontSize: 13.5, lineHeight: 1.6 }}>
        공격으로 판정된 플로우의 raw 레코드가 차단 규칙으로 등록됩니다. 행에 마우스를 올리면 해당
        플로우의 인코딩 이미지를 확인할 수 있고, 오탐이라 판단되면 삭제하세요. 서버 JSON에 즉시
        반영됩니다. <span className="muted">(시연용 JSON 시뮬레이션이며 실제 방화벽은 조작하지 않습니다)</span>
      </p>

      {rules.isLoading ? (
        <div className="empty"><span className="spin" /></div>
      ) : list.length === 0 ? (
        <div className="empty">
          차단 규칙이 없습니다. <Link to="/console" style={{ color: "var(--focus)" }}>분석 결과</Link>에서 공격
          플로우를 등록하세요
        </div>
      ) : (
        <div className="panel" style={{ padding: 0, overflow: "auto" }}>
          <table className="data">
            <thead>
              <tr>
                <th>RULE</th><th>식별자</th><th>SRC → DST</th><th>판정</th>
                <th>CONF</th><th>등록 시각</th><th></th>
              </tr>
            </thead>
            <tbody>
              {list.map((r) => (
                <FwRow
                  key={r.rule_id}
                  r={r}
                  expanded={expanded === r.rule_id}
                  confirming={confirming === r.rule_id}
                  deleting={del.isPending && del.variables === r.rule_id}
                  onHover={(x, y) => setHover({ rule: r, x, y })}
                  onLeave={() => setHover(null)}
                  onToggle={() => setExpanded(expanded === r.rule_id ? null : r.rule_id)}
                  onAskDelete={() => setConfirming(r.rule_id)}
                  onCancelDelete={() => setConfirming(null)}
                  onDelete={() => del.mutate(r.rule_id)}
                />
              ))}
            </tbody>
          </table>
        </div>
      )}

      {hover && (
        <div
          className="popover"
          style={{
            left: Math.min(hover.x + 18, window.innerWidth - 220),
            top: Math.min(hover.y + 14, window.innerHeight - 250),
          }}
        >
          <img src={api.ruleImageUrl(hover.rule.rule_id)} alt="flow encoding" />
          <div className="cap">
            {hover.rule.verdict.predicted_class}{" "}
            {fmtConf(hover.rule.verdict.confidence)}
          </div>
        </div>
      )}
    </>
  );
}

function FwRow(props: {
  r: FirewallRule;
  expanded: boolean;
  confirming: boolean;
  deleting: boolean;
  onHover: (x: number, y: number) => void;
  onLeave: () => void;
  onToggle: () => void;
  onAskDelete: () => void;
  onCancelDelete: () => void;
  onDelete: () => void;
}) {
  const { r } = props;
  const idf = r.identifier;
  const src = idf.src_ip ? `${idf.src_ip}:${idf.src_port ?? "?"}` : "—";
  const dst = idf.dst_ip
    ? `${idf.dst_ip}:${idf.dst_port ?? "?"}`
    : `dst-port ${idf.dst_port ?? "?"} (proto ${idf.protocol ?? "?"})`;

  return (
    <>
      <tr
        className="row-main"
        onMouseMove={(e) => props.onHover(e.clientX, e.clientY)}
        onMouseLeave={props.onLeave}
        onClick={props.onToggle}
        style={{ cursor: "pointer" }}
      >
        <td>{r.rule_id}</td>
        <td>
          <span
            className="badge"
            style={{
              background: idf.type === "ip_5tuple" ? "#2563eb1a" : "#5b688022",
              color: idf.type === "ip_5tuple" ? "var(--focus)" : "var(--muted)",
              border: "1px solid var(--line)",
            }}
          >
            {idf.type === "ip_5tuple" ? "IP 5-TUPLE" : "DST-PORT"}
          </span>
        </td>
        <td>{src} → {dst}</td>
        <td style={{ color: CLASS_COLORS[r.verdict.predicted_class] }}>
          {r.verdict.predicted_class}
        </td>
        <td>{fmtConf(r.verdict.confidence)}</td>
        <td className="muted">{r.created_at}</td>
        <td onClick={(e) => e.stopPropagation()}>
          {props.confirming ? (
            <span style={{ display: "flex", gap: 6 }}>
              <button className="btn danger" disabled={props.deleting} onClick={props.onDelete}>
                {props.deleting ? "…" : "확인"}
              </button>
              <button className="btn" onClick={props.onCancelDelete}>취소</button>
            </span>
          ) : (
            <button className="btn" onClick={props.onAskDelete}>삭제</button>
          )}
        </td>
      </tr>
      {props.expanded && (
        <tr>
          <td colSpan={7} style={{ background: "var(--panel-2)" }}>
            <div className="kv" style={{ padding: "8px 4px" }}>
              {Object.entries(r.raw_row).slice(0, 24).map(([k, v]) => (
                <div key={k}>
                  <span className="k">{k}</span>
                  <span className="v">{v === null ? "—" : String(v)}</span>
                </div>
              ))}
            </div>
            <div className="muted mono" style={{ fontSize: 11.5, padding: "4px 4px 8px" }}>
              source: {r.source.upload_id} #{r.source.row_index}
            </div>
          </td>
        </tr>
      )}
    </>
  );
}
