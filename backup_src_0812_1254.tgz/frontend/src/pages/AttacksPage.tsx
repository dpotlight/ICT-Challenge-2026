/** 공격 유형 — 두 축 필터 + 확장 유형 + 데이터셋 확장성 */
import { useState } from "react";
import { Link } from "react-router-dom";
import { ATTACKS } from "../attacksData";

type Axis = "nature" | "stage";

/* 성격별 묶음 */
const BY_NATURE: Array<{ key: string; title: string; desc: string; names: string[] }> = [
  {
    key: "avail",
    title: "가용성 마비",
    desc: "서비스를 못 쓰게 만드는 공격입니다. 트래픽의 양과 리듬이 무기입니다.",
    names: ["DoS", "DDoS"],
  },
  {
    key: "intrude",
    title: "침투 시도",
    desc: "문을 두드리는 공격입니다. 반복과 변칙의 패턴이 흔적으로 남습니다.",
    names: ["Brute Force", "Web"],
  },
  {
    key: "control",
    title: "잠입과 원격 제어",
    desc: "이미 들어온 뒤의 공격입니다. 주기적 교신과 은밀한 이동이 신호입니다.",
    names: ["Infiltration", "Botnet"],
  },
];

/* 공격 단계별 묶음 */
const BY_STAGE: Array<{ key: string; title: string; desc: string; names: string[] }> = [
  {
    key: "s1",
    title: "1단계 접근 시도",
    desc: "외부에서 문을 여는 단계입니다. 인증을 뚫거나 취약한 입력을 노립니다.",
    names: ["Brute Force", "Web"],
  },
  {
    key: "s2",
    title: "2단계 내부 확산",
    desc: "들어온 뒤 옆으로 옮겨 다니며 거점을 넓히는 단계입니다.",
    names: ["Infiltration"],
  },
  {
    key: "s3",
    title: "3단계 지속 교신",
    desc: "감염 단말이 공격 서버와 계속 연락을 주고받는 단계입니다.",
    names: ["Botnet"],
  },
  {
    key: "s4",
    title: "4단계 자원 소진",
    desc: "확보한 자원으로 서비스를 마비시키는 마지막 단계입니다.",
    names: ["DoS", "DDoS"],
  },
];

/* 업계가 함께 추적하는 유형 (확장 후보) */
const EXTENDED = [
  {
    name: "C2 Beaconing",
    ko: "명령 제어 교신",
    stage: "지속 교신",
    trace: "고정 주기 접속과 균일한 패킷 크기",
    note: "감염 단말이 공격 서버와 주고받는 주기적 심박입니다. Botnet 탐지를 일반화한 형태입니다.",
  },
  {
    name: "Ransomware Activity",
    ko: "랜섬웨어 활동",
    stage: "내부 확산",
    trace: "짧은 시간 대량 세션과 급증한 내부 전송량",
    note: "암호화 직전의 대량 파일 접근과 내부 확산 트래픽에서 신호가 잡힙니다.",
  },
  {
    name: "Lateral Movement",
    ko: "측면 이동",
    stage: "내부 확산",
    trace: "내부 대 내부 신규 연결 급증",
    note: "내부망 안에서 옆 시스템으로 옮겨가는 움직임입니다. ATT&CK TA0008에 해당합니다.",
  },
  {
    name: "Data Exfiltration",
    ko: "데이터 유출",
    stage: "유출",
    trace: "평소와 반대인 상하행 비율과 장시간 대용량 업로드",
    note: "사고를 사건으로 만드는 마지막 단계입니다. 방향과 볼륨의 이상으로 드러납니다.",
  },
  {
    name: "Cryptomining",
    ko: "암호화폐 채굴",
    stage: "지속 교신",
    trace: "채굴 풀과의 장시간 세션과 일정한 소패킷 반복",
    note: "탈취한 자원으로 채굴 풀과 계속 통신합니다. 특유의 프로토콜 리듬이 있습니다.",
  },
  {
    name: "Port Scan",
    ko: "포트 스캔",
    stage: "정찰",
    trace: "짧은 시간 다수 포트에 대한 미완성 세션",
    note: "본격 공격 전에 열린 문을 찾는 정찰입니다. CIC-IDS2017에 포함된 클래스입니다.",
  },
  {
    name: "DNS Tunneling",
    ko: "DNS 터널링",
    stage: "유출",
    trace: "비정상적으로 긴 도메인 질의와 높은 질의 빈도",
    note: "DNS 프로토콜에 데이터를 실어 내보내는 우회 통로입니다.",
  },
  {
    name: "Insider Threat",
    ko: "내부자 위협",
    stage: "내부 확산",
    trace: "정상 계정의 시간대와 접근 범위 이탈",
    note: "시그니처가 아니라 행동 기준선으로만 보이는 유형입니다.",
  },
];

/* 데이터셋 확장성 */
const DATASETS = [
  {
    name: "CSE-CIC-IDS2018",
    org: "캐나다 사이버보안연구소",
    status: "done",
    statusKo: "학습과 검증 완료",
    classes: "Brute Force, DoS, DDoS, Web Attack, Infiltration, Botnet, Heartbleed",
    note: "현재 모델이 학습한 데이터셋입니다. 관제 콘솔에서 판별하는 6종이 여기서 나왔습니다.",
  },
  {
    name: "CIC-IDS2017",
    org: "캐나다 사이버보안연구소",
    status: "doing",
    statusKo: "실험 진행 중",
    classes: "위 유형에 더해 Port Scan 추가",
    note: "같은 파이프라인에 다른 연도의 데이터를 넣어 새 클래스가 추가돼도 구조가 유지되는지 확인하고 있습니다.",
  },
  {
    name: "UNSW-NB15",
    org: "호주 사이버보안센터",
    status: "next",
    statusKo: "확장 후보",
    classes: "Fuzzers, Analysis, Backdoor, DoS, Exploits, Generic, Reconnaissance, Shellcode, Worms",
    note: "공격 분류 체계가 전혀 다른 데이터셋입니다. 여기서도 동작하면 특정 데이터셋에 종속되지 않는다는 근거가 됩니다.",
  },
  {
    name: "CIC-DDoS2019",
    org: "캐나다 사이버보안연구소",
    status: "next",
    statusKo: "확장 후보",
    classes: "NTP, DNS, LDAP, SNMP, SSDP 등 반사 증폭형 DDoS 세분류",
    note: "하나의 공격 계열을 더 잘게 나눈 데이터셋으로 세분류 성능을 확인합니다.",
  },
];

function byNames(names: string[]) {
  return names.map((n) => ATTACKS.find((a) => a.name === n)).filter(Boolean) as typeof ATTACKS;
}

export default function AttacksPage() {
  const [axis, setAxis] = useState<Axis>("nature");
  const groups = axis === "nature" ? BY_NATURE : BY_STAGE;

  return (
    <div className="tp atk">
      {/* 히어로 */}
      <section className="tp-hero">
        <span className="tp-eyebrow">THREAT COVERAGE</span>
        <h1>
          내용을 감춰도
          <br />
          행동의 리듬은 남습니다
        </h1>
        <p className="tp-lead">
          공격은 목적에 따라 성격이 다르고 남기는 흔적의 리듬도 다릅니다. 공통점은 하나입니다.{" "}
          <b>페이로드를 암호화해도 행동의 리듬은 숨길 수 없다</b>는 것입니다. 제로-클라가 현재
          판별하는 6종과 같은 원리로 확장되는 유형을 함께 정리했습니다.
        </p>
        <dl className="tp-spec">
          <div>
            <dt>현재 판별</dt>
            <dd>6종</dd>
          </div>
          <div>
            <dt>확장 후보</dt>
            <dd>{EXTENDED.length}종</dd>
          </div>
          <div>
            <dt>검증 데이터셋</dt>
            <dd>{DATASETS.length}종</dd>
          </div>
        </dl>
      </section>

      {/* 판별 6종 */}
      <section className="atk-sec">
        <div className="atk-sec-top">
          <div>
            <span className="tp-eyebrow">DETECTIONS</span>
            <h2>제로-클라가 판별하는 유형</h2>
          </div>
          <div className="atk-tabs" role="tablist">
            <button
              role="tab"
              aria-selected={axis === "nature"}
              className={axis === "nature" ? "on" : ""}
              onClick={() => setAxis("nature")}
            >
              성격별
            </button>
            <button
              role="tab"
              aria-selected={axis === "stage"}
              className={axis === "stage" ? "on" : ""}
              onClick={() => setAxis("stage")}
            >
              공격 단계별
            </button>
          </div>
        </div>

        <div className="atk-groups">
          {groups.map((g) => (
            <div className="atk-grp" key={g.key}>
              <div className="atk-grp-head">
                <b>{g.title}</b>
                <span>{g.desc}</span>
              </div>
              <div className="atk-cards">
                {byNames(g.names).map((a) => (
                  <Link to={`/attacks/${a.id}`} className="atk-card" key={a.id}>
                    <span className="atk-card-name">{a.name}</span>
                    <p>{a.oneliner}</p>
                    <span className="atk-card-go">
                      자세히 보기
                      <svg width="12" height="12" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                        <path d="M2.5 8h11M9 3.5 13.5 8 9 12.5" />
                      </svg>
                    </span>
                  </Link>
                ))}
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* 확장 유형 */}
      <section className="atk-sec">
        <span className="tp-eyebrow">EXTENSION</span>
        <h2>같은 원리로 확장되는 유형</h2>
        <p className="atk-lead">
          업계 주요 벤더가 공통으로 추적하는 행위들입니다. 모두 내용이 아니라 행동으로 드러나기
          때문에 제로-클라의 판별 구조가 그대로 적용됩니다. 오른쪽은 각 유형이 플로우 통계에 남기는
          흔적입니다.
        </p>
        <div className="atk-ext-list">
          {EXTENDED.map((e) => (
            <div className="atk-ext-row" key={e.name}>
              <div className="atk-ext-name">
                <b>{e.name}</b>
                <span>{e.ko}</span>
                <em>{e.stage}</em>
              </div>
              <p>{e.note}</p>
              <span className="atk-ext-trace">{e.trace}</span>
            </div>
          ))}
        </div>
      </section>

      {/* 데이터셋 확장성 */}
      <section className="atk-sec">
        <span className="tp-eyebrow">DATASET</span>
        <h2>하나의 데이터셋에 묶이지 않습니다</h2>
        <p className="atk-lead">
          탐지 클래스는 데이터셋이 정합니다. 그래서 다른 데이터셋을 넣었을 때도 같은 파이프라인이
          동작하는지가 확장성의 핵심입니다. 우리 구조는 플로우 통계를 관계 행렬로 바꾸는 방식이라
          <b> 피처 이름이나 클래스 개수가 달라져도 그대로 적용됩니다.</b>
        </p>
        <div className="atk-ds">
          {DATASETS.map((d) => (
            <div className={`atk-ds-row ${d.status}`} key={d.name}>
              <div className="atk-ds-head">
                <b>{d.name}</b>
                <span className={`atk-ds-badge ${d.status}`}>{d.statusKo}</span>
              </div>
              <span className="atk-ds-org">{d.org}</span>
              <span className="atk-ds-cls">{d.classes}</span>
              <p>{d.note}</p>
            </div>
          ))}
        </div>
        <span className="atk-src">
          데이터셋 정보는 각 기관의 공식 배포 페이지 기준입니다. 확장 후보는 실환경 검증 단계에서
          순차 적용할 계획입니다.
        </span>
      </section>
    </div>
  );
}
