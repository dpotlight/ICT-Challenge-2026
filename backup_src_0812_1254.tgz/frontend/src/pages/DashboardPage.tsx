import { useEffect, useMemo, useRef, useState } from "react";
import { Link, useLocation, useNavigate, useParams } from "react-router-dom";
import { useInfiniteQuery, useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { api } from "../api/client";
import { CLASS_COLORS, type FlowRow } from "../types";
import { fmtConf } from "../format";

const PAGE = 20;

export interface FlowFilter {
  classes: string[];   // 빈 배열 = 전체 보기
}

export default function DashboardPage() {
  const { id = "" } = useParams();
  const nav = useNavigate();
  const qc = useQueryClient();
  const location = useLocation();
  // 필터는 URL에 노출하지 않고 라우터 내부 state 로 유지
  const [filter, setFilter] = useState<FlowFilter>(
    () => (location.state as { filter?: FlowFilter } | null)?.filter ?? { classes: [] },
  );
  const { classes } = filter;
  const [sort, setSort] = useState<string>("row");
  const [toast, setToast] = useState<string | null>(null);

  const toggleClass = (c: string) =>
    setFilter({
      classes: classes.includes(c) ? classes.filter((x) => x !== c) : [...classes, c],
    });

  const summary = useQuery({ queryKey: ["upload", id], queryFn: () => api.upload(id) });
  const sys = useQuery({ queryKey: ["system"], queryFn: api.system, refetchInterval: 3000 });
  const sessions = useQuery({ queryKey: ["uploads"], queryFn: api.uploads });

  const flows = useInfiniteQuery({
    queryKey: ["flows", id, classes, sort],
    queryFn: ({ pageParam }) => api.flows(id, pageParam as number, PAGE, classes, sort),
    initialPageParam: 0,
    getNextPageParam: (last) =>
      last.offset + PAGE < last.total ? last.offset + PAGE : undefined,
  });

  const rows: FlowRow[] = useMemo(
    () => flows.data?.pages.flatMap((p) => p.rows) ?? [],
    [flows.data],
  );

  // 무한 스크롤: 그리드 하단 센티널이 보이면 다음 페이지 자동 로드
  const sentinelRef = useRef<HTMLDivElement | null>(null);
  useEffect(() => {
    const el = sentinelRef.current;
    if (!el) return;
    const io = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting && flows.hasNextPage && !flows.isFetchingNextPage) {
          flows.fetchNextPage();
        }
      },
      { rootMargin: "600px 0px" },   // 바닥 도달 전에 미리 로드
    );
    io.observe(el);
    return () => io.disconnect();
  }, [flows.hasNextPage, flows.isFetchingNextPage, flows.fetchNextPage, rows.length]);

  const registerAll = useMutation({
    mutationFn: () => api.addAllAttacks(id),
    onSuccess: (r) => {
      setToast(`방화벽 등록: 신규 ${r.created.length}건, 중복 ${r.duplicated.length}건`);
      qc.invalidateQueries({ queryKey: ["flows", id] });
      setTimeout(() => setToast(null), 4000);
    },
  });

  const s = summary.data;

  return (
    <>
      <div style={{ display: "flex", alignItems: "center", gap: 16, flexWrap: "wrap" }}>
        <h1 style={{ fontSize: 22 }}>분석 결과</h1>
        {sessions.data && sessions.data.length > 0 && (
          <select
            className="btn"
            style={{ fontSize: 13, maxWidth: 320 }}
            value={id}
            onChange={(e) => nav(`/uploads/${e.target.value}`)}
          >
            {sessions.data.map((x) => (
              <option key={x.upload_id} value={x.upload_id}>
                {x.filename} ({x.n_rows}행)
              </option>
            ))}
          </select>
        )}
        <span style={{ marginLeft: "auto", display: "flex", gap: 10 }}>
          <Link to={`/uploads/${id}/report`} className="btn">위협 브리핑</Link>
          <Link to="/console" className="btn">＋ 다른 CSV 분석</Link>
        </span>
      </div>

      {s?.warnings?.length ? (
        <div className="warn">
          <span className="wi">!</span>
          {s.warnings.join(" / ")}
        </div>
      ) : null}

      {s && (
        <div className="kpis">
          <div className="kpi">
            <span className="k">총 플로우</span>
            <span className="v">{s.n_rows.toLocaleString()}</span>
          </div>
          <div className="kpi alert">
            <span className="k">공격 탐지</span>
            <span className="v">{s.n_attacks.toLocaleString()}</span>
          </div>
          <div className="kpi">
            <span className="k">공격 비율</span>
            <span className="v">{s.n_rows ? ((s.n_attacks / s.n_rows) * 100).toFixed(1) : "0.0"}%</span>
          </div>
          <div className="kpi">
            <span className="k">클래스 분포</span>
            <div className="dist" role="img" aria-label="클래스별 비율 막대">
              {Object.entries(s.class_counts)
                .filter(([, n]) => n > 0)
                .map(([c, n]) => (
                  <span
                    key={c}
                    title={`${c} ${n}건`}
                    style={{ width: `${(n / s.n_rows) * 100}%`, background: CLASS_COLORS[c] ?? "var(--muted)" }}
                  />
                ))}
            </div>
            <div className="dist-legend">
              {Object.entries(s.class_counts)
                .filter(([, n]) => n > 0)
                .map(([c, n]) => (
                  <span key={c}>
                    <i style={{ background: CLASS_COLORS[c] ?? "var(--muted)" }} />
                    {c} {n}
                  </span>
                ))}
            </div>
          </div>
        </div>
      )}

      {(s?.perf || sys.data) && (
        <div className="perf">
          {s?.perf && (
            <>
              <div className="pf">
                <span className="k">추론 지연</span>
                <span className="v">{s.perf.per_flow_ms} ms<span className="u">/플로우</span></span>
              </div>
              <div className="pf">
                <span className="k">처리량</span>
                <span className="v">{s.perf.flows_per_s?.toLocaleString() ?? "측정 전"}<span className="u"> flows/s</span></span>
              </div>
            </>
          )}
          {sys.data?.cpu_pct != null && (
            <div className="pf wide">
              <span className="k">CPU 부하</span>
              <div className="gbar"><div style={{ width: `${sys.data.cpu_pct}%` }} /></div>
              <span className="v">{sys.data.cpu_pct}%</span>
            </div>
          )}
          {sys.data?.mem_pct != null && (
            <div className="pf wide">
              <span className="k">메모리</span>
              <div className="gbar"><div style={{ width: `${sys.data.mem_pct}%` }} /></div>
              <span className="v">{sys.data.mem_used_gb}<span className="u">/{sys.data.mem_total_gb} GB</span></span>
            </div>
          )}
          {sys.data && (
            <div className="pf">
              <span className="k">추론 디바이스</span>
              <span className="v">{(s?.perf?.device ?? sys.data.device).toUpperCase()}</span>
            </div>
          )}
        </div>
      )}

      {s && (
        <div style={{ display: "flex", gap: 8, flexWrap: "wrap", alignItems: "center", margin: "18px 0 22px" }}>
          <button
            className={`chip clickable ${classes.length === 0 ? "active" : ""}`}
            title="전체 보기 (필터 해제)"
            onClick={() => setFilter({ classes: [] })}
          >
            <span className="dot" style={{ background: "var(--muted)" }} />
            전체 {s.n_rows}
          </button>
          {Object.entries(s.class_counts)
            .filter(([, n]) => n > 0)
            .map(([c, n]) => (
              <button
                key={c}
                className={`chip clickable ${classes.includes(c) ? "active" : ""}`}
                title={`${c} 판정 ${classes.includes(c) ? "제외" : "포함"} (다중 선택 가능)`}
                onClick={() => toggleClass(c)}
              >
                <span className="dot" style={{ background: CLASS_COLORS[c] ?? "var(--muted)" }} />
                {c} {n}
              </button>
            ))}
          <select
            className="btn"
            style={{ fontSize: 13 }}
            value={sort}
            title="정렬 기준"
            onChange={(e) => setSort(e.target.value)}
          >
            <option value="row">행 순서</option>
            <option value="conf_asc">신뢰도 낮은순 (검토 우선)</option>
            <option value="conf_desc">신뢰도 높은순</option>
          </select>
          <span style={{ marginLeft: "auto", display: "flex", gap: 10 }}>
            <button
              className="btn danger"
              disabled={!s?.n_attacks || registerAll.isPending}
              onClick={() => registerAll.mutate()}
            >
              {registerAll.isPending ? "등록 중…" : "공격 전체 방화벽 등록"}
            </button>
            <Link to="/firewall" className="btn">방화벽 관리 →</Link>
          </span>
        </div>
      )}

      {toast && (
        <div className="panel" style={{ marginBottom: 16, borderColor: "var(--focus)", padding: 12 }}>
          {toast}
        </div>
      )}

      {flows.isLoading ? (
        <div className="empty"><span className="spin" /></div>
      ) : rows.length === 0 ? (
        <div className="empty">표시할 플로우가 없습니다</div>
      ) : (
        <>
          <div className="flow-grid">
            {rows.map((r) => (
              <div
                key={r.row_index}
                className={`flow-card ${r.is_attack ? "attack" : ""}`}
                onClick={() => nav(`/uploads/${id}/flows/${r.row_index}`, { state: { filter } })}
                title={`#${r.row_index} ${r.pred_class}`}
              >
                <img loading="lazy" src={api.imageUrl(id, r.row_index)} alt={`flow ${r.row_index}`} />
                {r.rule_id && <span className="ruled" title="방화벽 차단 규칙 등록됨">차단룰 ✓</span>}
                <div className="meta">
                  <span className="cls" style={{ color: CLASS_COLORS[r.pred_class] ?? "var(--text)" }}>
                    {r.pred_class}
                  </span>
                  <span className="conf" title={`softmax ${(r.confidence * 100).toFixed(4)}%`}>{fmtConf(r.confidence)}</span>
                </div>
              </div>
            ))}
          </div>
          <div ref={sentinelRef} style={{ height: 1 }} />
          {flows.isFetchingNextPage && (
            <div style={{ textAlign: "center", marginTop: 18 }}>
              <span className="spin" />
              <span className="muted mono" style={{ marginLeft: 10, fontSize: 12.5 }}>
                {rows.length} / {flows.data?.pages[0].total}
              </span>
            </div>
          )}
        </>
      )}
    </>
  );
}


