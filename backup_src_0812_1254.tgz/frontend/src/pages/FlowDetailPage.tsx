import { useEffect } from "react";
import { Link, useLocation, useNavigate, useParams } from "react-router-dom";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { api } from "../api/client";
import { explainVerdict, fieldKo, fmtConf } from "../format";
import { CLASS_TO_ATTACK } from "../attacksData";
import { useState } from "react";
import { CLASS_COLORS } from "../types";
import type { FlowFilter } from "./DashboardPage";

export default function FlowDetailPage() {
  const { id = "", row = "0" } = useParams();
  const rowIdx = Number(row);
  const qc = useQueryClient();
  const nav = useNavigate();
  const location = useLocation();
  // 필터는 URL이 아닌 라우터 내부 state 로 전달받음
  const filter: FlowFilter =
    (location.state as { filter?: FlowFilter } | null)?.filter ?? { classes: [] };
  const { classes } = filter;
  const filterLabel = classes.length ? classes.join(", ") : null;

  const flow = useQuery({ queryKey: ["flow", id, rowIdx], queryFn: () => api.flow(id, rowIdx) });
  const meta = useQuery({ queryKey: ["meta"], queryFn: api.meta });
  const [hl, setHl] = useState<[number, number] | null>(null);
  const K = meta.data?.K ?? 44;
  const flowNav = useQuery({
    queryKey: ["flow-nav", id, rowIdx, classes],
    queryFn: () => api.flowNav(id, rowIdx, classes),
  });
  const feats = useQuery({
    queryKey: ["gradcam-feats", id, rowIdx],
    queryFn: () => api.gradcamFeatures(id, rowIdx, 5),
    enabled: !!flow.data,
  });

  const similar = useQuery({
    queryKey: ["similar", id, rowIdx],
    queryFn: () => api.similar(id, rowIdx, 6),
    enabled: !!flow.data,
  });

  const register = useMutation({
    mutationFn: () => api.addRule(id, rowIdx),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["flow", id, rowIdx] }),
  });

  const goPrev = flowNav.data?.prev ?? null;
  const goNext = flowNav.data?.next ?? null;

  const goTo = (target: number | null) => {
    if (target !== null) nav(`/uploads/${id}/flows/${target}`, { state: { filter } });
  };

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "ArrowLeft") goTo(goPrev);
      if (e.key === "ArrowRight") goTo(goNext);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [goPrev, goNext, id, classes]);

  if (flow.isLoading) return <div className="empty"><span className="spin" /></div>;
  if (!flow.data) return <div className="empty">플로우를 찾을 수 없습니다</div>;
  const f = flow.data;

  return (
    <>
      <button className="side-nav left" disabled={goPrev === null} title="이전 플로우 (←)"
              onClick={() => goTo(goPrev)}>
        ‹
      </button>
      <button className="side-nav right" disabled={goNext === null} title="다음 플로우 (→)"
              onClick={() => goTo(goNext)}>
        ›
      </button>

      <div style={{ display: "flex", alignItems: "center", gap: 14, marginBottom: 20, flexWrap: "wrap" }}>
        <Link to={`/uploads/${id}`} state={{ filter }} className="btn">
          ← 결과로{filterLabel ? ` (${filterLabel})` : ""}
        </Link>
        {flowNav.data?.pos != null && (
          <span className="muted" style={{ fontSize: 13 }}>
            {flowNav.data.pos} / {flowNav.data.total}
            {filterLabel ? ` (${filterLabel} 필터)` : ""}
          </span>
        )}
        <h1 style={{ fontSize: 20 }} className="mono">flow #{f.row_index}</h1>
        <span className={`badge ${f.is_attack ? "attack" : "benign"}`}>
          {f.is_attack ? "ATTACK" : "BENIGN"}
        </span>
        <span className="chip">
          <span className="dot" style={{ background: CLASS_COLORS[f.pred_class] }} />
          {f.pred_class} {fmtConf(f.confidence)}
        </span>
        {f.is_attack && (
          <span style={{ marginLeft: "auto" }}>
            {f.rule_id ? (
              <Link to="/firewall" className="btn">✓ 방화벽 등록됨</Link>
            ) : (
              <button className="btn danger" disabled={register.isPending} onClick={() => register.mutate()}>
                {register.isPending ? "등록 중…" : "이 플로우 방화벽 등록"}
              </button>
            )}
          </span>
        )}
      </div>

      <div className="detail-grid">
        <div className="img-frame">
          <img src={api.imageUrl(id, rowIdx)} alt="encoding" />
          <div className="cap">플로우 통계의 관계 행렬 (인코딩 이미지)</div>
        </div>
        <div className="img-frame">
          <div className="img-wrap">
            <img src={api.gradcamUrl(id, rowIdx)} alt="grad-cam" />
            {hl && (
              <>
                <span className="hl-row" style={{ top: `${(hl[0] / K) * 100}%`, height: `${100 / K}%` }} />
                <span className="hl-col" style={{ left: `${(hl[1] / K) * 100}%`, width: `${100 / K}%` }} />
                <span
                  className="hl-cell"
                  style={{
                    top: `${(hl[0] / K) * 100}%`,
                    left: `${(hl[1] / K) * 100}%`,
                    width: `${100 / K}%`,
                    height: `${100 / K}%`,
                  }}
                />
              </>
            )}
          </div>
          <div className="cap">{f.pred_class} 판정 근거 영역 (Grad-CAM)</div>
        </div>
      </div>

      <div className="detail-grid" style={{ marginTop: 22 }}>
        <section className="panel">
          <h2>클래스 확률</h2>
          {f.classes.map((c, i) => (
            <div className="prob-row" key={c}>
              {CLASS_TO_ATTACK[c] ? (
                <Link
                  to={`/attacks/${CLASS_TO_ATTACK[c]}`}
                  className="name cls-link"
                  title={`${c} 공격 유형 설명 보기`}
                >
                  {c} ↗
                </Link>
              ) : (
                <span className="name">{c}</span>
              )}
              <div className="prob-bar">
                <div
                  style={{
                    width: `${Math.max(f.probs[i] * 100, 0.5)}%`,
                    background: CLASS_COLORS[c] ?? "var(--focus)",
                    opacity: c === f.pred_class ? 1 : 0.45,
                  }}
                />
              </div>
              <span className="val">{(f.probs[i] * 100).toFixed(2)}%</span>
            </div>
          ))}
        </section>

        <section className="panel">
          <h2>판정 근거 (Grad-CAM Top 5 피처쌍)</h2>
          {feats.data?.pairs.length ? (
            <p className="verdict-text">{explainVerdict(f.pred_class, feats.data.pairs)}</p>
          ) : null}
          {feats.isLoading ? (
            <span className="spin" />
          ) : (
            <table className="data">
              <thead>
                <tr><th>#</th><th>픽셀</th><th>피처 i</th><th>피처 j</th><th>활성도</th></tr>
              </thead>
              <tbody>
                {feats.data?.pairs.map((p, i) => (
                  <tr
                    key={i}
                    className="row-main hoverable"
                    onMouseEnter={() => setHl([p.pixel[0], p.pixel[1]])}
                    onMouseLeave={() => setHl(null)}
                  >
                    <td>{i + 1}</td>
                    <td>({p.pixel[0]}, {p.pixel[1]})</td>
                    <td>{p.feature_i}</td>
                    <td>{p.feature_j}</td>
                    <td>{p.score.toFixed(3)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}

        </section>
      </div>

      {similar.data?.rows.length ? (
        <section className="panel" style={{ marginTop: 22 }}>
          <h2>행위가 비슷한 플로우 <span className="h-sub">스케일된 피처 공간의 코사인 유사도 상위 6건</span></h2>
          <div className="sim-grid">
            {similar.data.rows.map((r) => (
              <div
                key={r.row_index}
                className={`flow-card ${r.is_attack ? "attack" : ""}`}
                onClick={() => nav(`/uploads/${id}/flows/${r.row_index}`, { state: { filter } })}
                title={`#${r.row_index} ${r.pred_class}`}
              >
                <img loading="lazy" src={api.imageUrl(id, r.row_index)} alt={`flow ${r.row_index}`} />
                {r.rule_id && <span className="ruled">차단룰 ✓</span>}
                <div className="meta">
                  <span className="cls" style={{ color: CLASS_COLORS[r.pred_class] ?? "var(--text)" }}>
                    {r.pred_class}
                  </span>
                  <span className="conf">{(r.similarity * 100).toFixed(1)}% 유사</span>
                </div>
              </div>
            ))}
          </div>
          <p className="sim-note">
            유사도는 판정 결과가 아니라 행동 패턴의 거리입니다. 같은 공격 캠페인에 속한
            플로우를 한 번에 모아 검토하거나 오탐 후보를 묶어서 확인할 때 사용하세요.
          </p>
        </section>
      ) : null}

      <section className="panel" style={{ marginTop: 22 }}>
        <h2>원본 플로우 레코드 (Raw Flow Record)</h2>
        <div className="kv">
          {Object.entries(f.raw_row).map(([k, v]) => (
            <div key={k}>
              <span className="k">
                {k}
                {fieldKo(k) && <em className="kk">{fieldKo(k)}</em>}
              </span>
              <span className="v">{v === null ? "값 없음" : String(v)}</span>
            </div>
          ))}
        </div>
      </section>
    </>
  );
}
