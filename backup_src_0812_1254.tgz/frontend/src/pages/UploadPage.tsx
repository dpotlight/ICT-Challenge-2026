import { useCallback, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { api } from "../api/client";
import { CLASS_COLORS } from "../types";

export default function UploadPage() {
  const nav = useNavigate();
  const qc = useQueryClient();
  const [drag, setDrag] = useState(false);
  const [profile, setProfile] = useState("auto");
  const meta = useQuery({ queryKey: ["meta"], queryFn: api.meta });
  const sessions = useQuery({ queryKey: ["uploads"], queryFn: api.uploads });

  const upload = useMutation({
    mutationFn: (f: File) => api.uploadCsv(f, profile),
    onSuccess: (r) => nav(`/uploads/${r.upload_id}`),
  });

  const delSession = useMutation({
    mutationFn: api.deleteUpload,
    onSuccess: () => qc.invalidateQueries({ queryKey: ["uploads"] }),
  });

  const onFile = useCallback(
    (f: File | undefined) => {
      if (f) upload.mutate(f);
    },
    [upload],
  );

  return (
    <>
      <section className="hero compact">
        <h1>관제 콘솔</h1>
        <p className="sub">
          플로우 CSV를 업로드하면 위협 여부를 판별하고 판단 근거까지 함께 보여줍니다.
        </p>
      </section>

      <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 12 }}>
        <span className="muted" style={{ fontSize: 13 }}>추출 도구</span>
        <select
          className="btn"
          style={{ fontSize: 13 }}
          value={profile}
          onChange={(e) => setProfile(e.target.value)}
          title="플로우 피처를 추출한 도구입니다. 컬럼명과 단위를 자동 변환합니다"
        >
          <option value="auto">자동 감지</option>
          <option value="cicflowmeter">CICFlowMeter (신형과 구형)</option>
          <option value="nfstream">NFStream</option>
        </select>
        {meta.data && (
          <span className="muted" style={{ fontSize: 13.5 }}>
            현재 모델은 {meta.data.K}×{meta.data.K} 관계 행렬로 {meta.data.classes.length}개
            클래스를 판별합니다
          </span>
        )}
      </div>

      <div
        className={`dropzone ${drag ? "drag" : ""}`}
        onDragOver={(e) => {
          e.preventDefault();
          setDrag(true);
        }}
        onDragLeave={() => setDrag(false)}
        onDrop={(e) => {
          e.preventDefault();
          setDrag(false);
          onFile(e.dataTransfer.files[0]);
        }}
        onClick={() => document.getElementById("file-input")?.click()}
      >
        {upload.isPending ? (
          <>
            <span className="spin" />
            <div className="big" style={{ marginTop: 14 }}>
              분석 중입니다
            </div>
            <div className="muted">플로우 수에 따라 수 초가 걸릴 수 있습니다</div>
          </>
        ) : (
          <>
            <div className="big">트래픽 CSV를 끌어다 놓기</div>
            <div className="muted">또는 클릭해서 선택하세요 (CSV)</div>
          </>
        )}
        <input
          id="file-input"
          type="file"
          accept=".csv"
          hidden
          onChange={(e) => onFile(e.target.files?.[0])}
        />
      </div>

      {upload.isError && (
        <div className="panel" style={{ marginTop: 16, borderColor: "var(--alert)" }}>
          <b style={{ color: "var(--alert)" }}>업로드 실패</b>
          <div className="muted" style={{ marginTop: 6, fontSize: 13 }}>
            {String(upload.error)}
          </div>
        </div>
      )}

      <section style={{ marginTop: 40 }}>
        <h2 className="muted" style={{ fontSize: 14, letterSpacing: "0.1em", marginBottom: 14 }}>
          최근 분석 세션
        </h2>
        {sessions.data?.length ? (
          <div style={{ display: "grid", gap: 10 }}>
            {sessions.data.map((s) => (
              <div
                key={s.upload_id}
                className="panel"
                style={{ display: "flex", alignItems: "center", gap: 18, cursor: "pointer", padding: 16 }}
                onClick={() => nav(`/uploads/${s.upload_id}`)}
              >
                <span className="mono" style={{ fontSize: 13 }}>{s.filename}</span>
                <span className="muted mono" style={{ fontSize: 12 }}>{s.created_at}</span>
                <span style={{ marginLeft: "auto", display: "flex", gap: 6, alignItems: "center" }}>
                  <span className="chip">
                    <span className="dot" style={{ background: "var(--muted)" }} />
                    {s.n_rows} flows
                  </span>
                  <span className="chip" style={{ borderColor: s.n_attacks ? "#dc262655" : undefined }}>
                    <span className="dot" style={{ background: "var(--alert)" }} />
                    {s.n_attacks} attacks
                  </span>
                  <button
                    className="btn"
                    style={{ padding: "5px 12px", fontSize: 12.5 }}
                    disabled={delSession.isPending}
                    onClick={(e) => {
                      e.stopPropagation();
                      if (confirm(`세션 "${s.filename}" 을 삭제할까요?`)) delSession.mutate(s.upload_id);
                    }}
                  >
                    삭제
                  </button>
                </span>
              </div>
            ))}
          </div>
        ) : (
          <div className="empty">아직 분석한 세션이 없습니다</div>
        )}
      </section>

      {meta.data && (
        <section style={{ marginTop: 36 }}>
          <h2 className="muted" style={{ fontSize: 14, letterSpacing: "0.1em", marginBottom: 12 }}>
            판별 클래스
          </h2>
          <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
            {meta.data.classes.map((c) => (
              <span key={c} className="chip">
                <span className="dot" style={{ background: CLASS_COLORS[c] ?? "var(--muted)" }} />
                {c}
              </span>
            ))}
          </div>
        </section>
      )}
    </>
  );
}
