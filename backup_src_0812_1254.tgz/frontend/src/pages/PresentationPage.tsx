/**
 * 발표 자료 (/#/pt)
 * 01 국내 사고 → 02 미국 제재 → 03 시장 규모 → 04 기존 플레이어 → 05 빈칸 → 06 제로-클라 → 07 매출 전망
 * 수치는 원출처로 검증한 값만 사용한다. 매출 가정값은 ASSUME 한 곳에서 관리한다.
 */

/* ── 국내 사고 (검색 결과 캡처 + 확정 수치) ── */
const KR_CASES = [
  {
    org: "쿠팡",
    img: "/news/coupang.png?v=18",
    people: "3,755만 명",
    peopleCap: "유출된 개인정보",
    fine: "6,246억 8,100만 원",
    fineCap: "과징금, 역대 최대",
    extra: "과태료 1,680만 원",
    src: "개인정보보호위원회 제11회 전체회의 의결, 2026.06.11",
  },
  {
    org: "SK텔레콤",
    img: "/news/skt.png?v=18",
    people: "2,324만 명",
    peopleCap: "유심 정보 등 25종 유출",
    fine: "1,347억 9,100만 원",
    fineCap: "과징금, 당시 역대 최대",
    extra: "매출 3% 기준 산정",
    src: "개인정보보호위원회 제18회 전체회의, 2025.08.28",
  },
  {
    org: "롯데카드",
    img: "/news/lottecard.png?v=18",
    people: "297만 명",
    peopleCap: "회원 개인정보 유출",
    fine: "영업정지 1.5개월",
    fineCap: "카드사 최초 업무정지",
    extra: "과징금 50억 원",
    src: "금융위원회 제14차 회의 최종 의결, 2026.07.31",
  },
];

/* ── 미국 제재 (검색 결과 형식으로 재현) ── */
const US_CASES = [
  {
    site: "Texas Attorney General",
    url: "texasattorneygeneral.gov › news › releases",
    title: "Paxton Secures Historic $1.375 Billion Settlement with Google Related to Texans' Data Privacy Rights",
    date: "2025. 5.",
    snippet:
      "단일 주 정부가 구글로부터 받아낸 사상 최대 합의금. 위치 정보와 생체 정보를 동의 없이 수집한 혐의로 13억 7,500만 달러를 지급하기로 했다.",
    krw: "약 1조 9,250억 원",
  },
  {
    site: "Texas Attorney General",
    url: "texasattorneygeneral.gov › news › releases",
    title: "Paxton Secures $1.4 Billion Settlement with Meta Over Its Unauthorized Capture of Personal Biometric Data",
    date: "2024. 7.",
    snippet:
      "단일 주가 제기한 소송에서 나온 역대 최대 합의금. 이용자 얼굴 인식 데이터를 동의 없이 수집한 혐의다.",
    krw: "약 1조 9,600억 원",
  },
  {
    site: "Federal Communications Commission",
    url: "fcc.gov › document › enforcement",
    title: "T-Mobile to Pay $80 Million Penalty Over Data Breaches Affecting Millions of Customers",
    date: "2024. 9.",
    snippet:
      "여러 차례의 침해 사고에 대해 미국 연방통신위원회가 부과한 벌금. 함께 조사받은 AT&T는 5,700만 달러, Verizon은 4,700만 달러를 냈다.",
    krw: "약 1,120억 원",
  },
  {
    site: "Multi-State Attorneys General",
    url: "oag.state › press-release › marriott",
    title: "Marriott to Pay $52 Million and Overhaul Data Security After Breach of 300 Million Guest Records",
    date: "2024. 10.",
    snippet:
      "3억 건이 넘는 투숙객 기록이 유출된 사고에 대해 미국 여러 주가 공동으로 합의를 이끌어냈다.",
    krw: "약 728억 원",
  },
  {
    site: "Federal Trade Commission",
    url: "ftc.gov › enforcement › cases-proceedings",
    title: "Equifax to Pay Up to $700 Million in Settlement Over 2017 Data Breach",
    date: "2019. 7.",
    snippet:
      "1억 4,700만 명의 신용 정보가 유출된 사고. 연방거래위원회와 소비자금융보호국, 50개 주가 함께 합의를 성사시켰다.",
    krw: "약 9,800억 원",
  },
];

/* ── 시장 규모 ── */
const NDR_CAGR = 10.9;
const NDR_SERIES = [
  { y: "2026", v: 4.34 },
  { y: "2027", v: 4.81 },
  { y: "2028", v: 5.34 },
  { y: "2029", v: 5.92 },
  { y: "2030", v: 6.57 },
  { y: "2031", v: 7.29 },
];

const LEADERS = [
  { name: "Darktrace", country: "영국", note: "2년 연속 리더" },
  { name: "ExtraHop", country: "미국", note: "2년 연속 리더" },
  { name: "Vectra AI", country: "미국", note: "리더" },
];

const SEGMENTS = [
  {
    tag: "A",
    title: "오픈소스",
    who: "Suricata, Zeek, Arkime, Malcolm",
    how: "룰과 시그니처로 걸러내고 최종 판단은 사람이 합니다.",
    limit: "암호화 앞에서 멈춥니다",
  },
  {
    tag: "B",
    title: "복호화 기반 상용",
    who: "ExtraHop, 쿼드마이너, 코닉글로리",
    how: "트래픽을 열거나 풀패킷을 저장해 내용을 직접 봅니다.",
    limit: "키 관리와 저장 비용, 프라이버시 부담",
  },
  {
    tag: "C",
    title: "무복호화 AI",
    who: "Darktrace, Vectra, Exeon, Cisco ETA",
    how: "메타데이터만으로 열지 않고 이상 징후를 찾습니다.",
    limit: "판단 근거를 설명하지 못합니다",
  },
];

const AXES = ["무복호화", "판정 근거 설명", "경량 엣지 배포"];
const MATRIX = [
  { name: "오픈소스 (Suricata 등)", v: [1, 0, 1] },
  { name: "ExtraHop", v: [0, 1, 0] },
  { name: "Darktrace", v: [2, 1, 0] },
  { name: "Vectra AI", v: [2, 1, 0] },
  { name: "Exeon", v: [2, 1, 0] },
  { name: "Cisco ETA", v: [2, 0, 0] },
  { name: "ZERO-CLA", v: [2, 2, 2], us: true },
];
const MARK = ["없음", "일부", "있음"];

/* ── 매출 전망 가정값 ── */
const ASSUME = {
  domesticInfoSec: 7.12,
  infoSecGrowth: 15.9,
  infoSecFirms: 876,
  targetFirms: 60,
  unitPrice: 0.8,
  plan: [
    { year: "2027", customers: 2, label: "PoC 전환 초기 고객" },
    { year: "2028", customers: 8, label: "관제 사업자로 확대" },
    { year: "2029", customers: 20, label: "마켓플레이스 병행" },
  ],
};

/* ── 섹션 헤더 ── */
function Head({ n, title, sub }: { n: string; title: string; sub: string }) {
  return (
    <header className="pt2-head">
      <span className="pt2-num">{n}</span>
      <div>
        <h2>{title}</h2>
        <p>{sub}</p>
      </div>
    </header>
  );
}

/* ── 차트 ── */
function MarketChart() {
  const W = 720;
  const H = 250;
  const PAD = { l: 44, r: 24, t: 30, b: 32 };
  const max = 8;
  const iw = W - PAD.l - PAD.r;
  const ih = H - PAD.t - PAD.b;
  const x = (i: number) => PAD.l + (iw / (NDR_SERIES.length - 1)) * i;
  const y = (v: number) => PAD.t + ih - (v / max) * ih;
  const line = NDR_SERIES.map((d, i) => `${i ? "L" : "M"} ${x(i)} ${y(d.v)}`).join(" ");
  const area = `${line} L ${x(NDR_SERIES.length - 1)} ${PAD.t + ih} L ${x(0)} ${PAD.t + ih} Z`;
  const last = NDR_SERIES.length - 1;

  return (
    <svg viewBox={`0 0 ${W} ${H}`} className="pt2-chart" role="img" aria-label="NDR 시장 규모 전망">
      {[0, 2, 4, 6, 8].map((g) => (
        <g key={g}>
          <line x1={PAD.l} y1={y(g)} x2={W - PAD.r} y2={y(g)} className="pt2-grid" />
          <text x={PAD.l - 10} y={y(g) + 4} textAnchor="end" className="pt2-axis">
            {g}
          </text>
        </g>
      ))}
      <path d={area} className="pt2-area" />
      <path d={line} className="pt2-line" />
      {NDR_SERIES.map((d, i) => (
        <g key={d.y}>
          <circle cx={x(i)} cy={y(d.v)} r={i === 0 || i === last ? 6 : 4} className="pt2-dot" />
          <text x={x(i)} y={H - 10} textAnchor="middle" className="pt2-axis">
            {d.y}
          </text>
        </g>
      ))}
      <text x={x(0) + 4} y={y(NDR_SERIES[0].v) - 15} className="pt2-pt-label">
        {NDR_SERIES[0].v}
      </text>
      <text x={x(last)} y={y(NDR_SERIES[last].v) - 15} textAnchor="end" className="pt2-pt-label accent">
        {NDR_SERIES[last].v}
      </text>
      <text x={PAD.l - 10} y={PAD.t - 12} textAnchor="end" className="pt2-axis">
        십억 달러
      </text>
    </svg>
  );
}

function RevenueChart() {
  const rows = ASSUME.plan.map((p) => ({ ...p, rev: p.customers * ASSUME.unitPrice }));
  const max = Math.max(...rows.map((r) => r.rev)) * 1.18;
  return (
    <div className="pt2-bars">
      {rows.map((r) => (
        <div key={r.year} className="pt2-bar-row">
          <span className="pt2-bar-year">{r.year}</span>
          <div className="pt2-bar-track">
            <div className="pt2-bar-fill" style={{ width: `${(r.rev / max) * 100}%` }} />
          </div>
          <span className="pt2-bar-val">
            <b>{r.rev.toFixed(1)}억 원</b>
            <em>
              고객사 {r.customers}곳, {r.label}
            </em>
          </span>
        </div>
      ))}
    </div>
  );
}

/* ── 페이지 ── */
export default function PresentationPage() {
  return (
    <div className="pt2">
      <section className="pt2-cover">
        <span className="pt2-kicker">ICT 챌린지 2026 결선</span>
        <h1>
          암호화된 트래픽을
          <br />
          열지 않고 판별합니다
        </h1>
        <p>Team 제로-클라</p>
      </section>

      {/* 01 국내 */}
      <section className="pt2-sec">
        <Head n="01" title="국내 사고와 제재" sub="지난 1년 사이 확정된 세 건입니다" />

        <div className="pt2-cases">
          {KR_CASES.map((c) => (
            <article key={c.org} className="pt2-case">
              <figure className="pt2-shot">
                <img src={c.img} alt={`${c.org} 관련 보도 검색 결과`} loading="lazy" />
              </figure>
              <div className="pt2-case-data">
                <b className="pt2-case-org">{c.org}</b>
                <div className="pt2-case-nums">
                  <div>
                    <strong>{c.people}</strong>
                    <span>{c.peopleCap}</span>
                  </div>
                  <div>
                    <strong className="alert">{c.fine}</strong>
                    <span>{c.fineCap}</span>
                  </div>
                </div>
                <span className="pt2-case-extra">{c.extra}</span>
                <span className="pt2-src">{c.src}</span>
              </div>
            </article>
          ))}
        </div>

        <p className="pt2-punch">
          유출은 하루에 끝나지 않았습니다. <b>수개월에 걸쳐</b> 진행됐습니다.
          <br />그 사이 트래픽은 계속 흐르고 있었지만 아무도 알아채지 못했습니다.
        </p>
      </section>

      {/* 02 미국 */}
      <section className="pt2-sec">
        <Head n="02" title="미국의 제재 규모" sub="같은 사고가 미국에서 나면 청구서가 조 단위로 바뀝니다" />

        <div className="pt2-serp">
          {US_CASES.map((u) => (
            <article key={u.title} className="pt2-serp-row">
              <div className="pt2-serp-meta">
                <span className="pt2-serp-site">{u.site}</span>
                <span className="pt2-serp-url">{u.url}</span>
              </div>
              <h3 className="pt2-serp-title">{u.title}</h3>
              <p className="pt2-serp-snip">
                <span className="pt2-serp-date">{u.date}</span>
                {u.snippet}
              </p>
              <span className="pt2-serp-krw">{u.krw}</span>
            </article>
          ))}
        </div>
        <span className="pt2-src">
          각 규제기관 공식 보도자료 기준입니다. 원화 환산은 1달러 1,400원을 적용한 참고값입니다.
        </span>
      </section>

      {/* 03 시장 */}
      <section className="pt2-sec">
        <Head n="03" title="시장 규모" sub="탐지 수요가 시장을 밀어 올리고 있습니다" />

        <div className="pt2-market">
          <div className="pt2-market-chart">
            <MarketChart />
            <span className="pt2-src">MarketsandMarkets, Network Detection and Response Market, 2026</span>
          </div>
          <div className="pt2-market-side">
            <div className="pt2-stat">
              <strong>{NDR_CAGR}%</strong>
              <span>글로벌 NDR 시장 연평균 성장률 (2026에서 2031)</span>
            </div>
            <div className="pt2-stat">
              <strong>아시아태평양</strong>
              <span>전 지역 가운데 가장 높은 성장률 구간</span>
            </div>
            <div className="pt2-stat">
              <strong>{ASSUME.domesticInfoSec}조 원</strong>
              <span>
                국내 정보보안 부문 매출, 전년 대비 {ASSUME.infoSecGrowth}% 성장, 사업체 {ASSUME.infoSecFirms}개사
              </span>
            </div>
            <span className="pt2-src">과학기술정보통신부와 KISIA, 2025년 국내 정보보호산업 실태조사</span>
          </div>
        </div>
      </section>

      {/* 04 기존 플레이어 */}
      <section className="pt2-sec">
        <Head n="04" title="기존 플레이어" sub="큰 회사들이 이미 자리를 잡고 있습니다" />

        <div className="pt2-leaders">
          {LEADERS.map((l) => (
            <div key={l.name} className="pt2-leader">
              <b>{l.name}</b>
              <span>{l.country}</span>
              <em>{l.note}</em>
            </div>
          ))}
        </div>
        <span className="pt2-src">2026 Gartner Magic Quadrant for Network Detection and Response 리더 사분면</span>

        <div className="pt2-segments">
          {SEGMENTS.map((s) => (
            <div key={s.tag} className="pt2-seg">
              <span className="pt2-seg-tag">{s.tag}</span>
              <b>{s.title}</b>
              <span className="pt2-seg-who">{s.who}</span>
              <p>{s.how}</p>
              <span className="pt2-seg-limit">{s.limit}</span>
            </div>
          ))}
        </div>
      </section>

      {/* 05 빈칸 */}
      <section className="pt2-sec">
        <Head n="05" title="비어 있는 자리" sub="세 가지를 동시에 가진 제품이 없습니다" />

        <div className="pt2-table-wrap">
          <table className="pt2-table">
            <thead>
              <tr>
                <th>제품</th>
                {AXES.map((a) => (
                  <th key={a}>{a}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {MATRIX.map((r) => (
                <tr key={r.name} className={r.us ? "us" : ""}>
                  <td>{r.name}</td>
                  {r.v.map((v, i) => (
                    <td key={i} className={`m m${v}`}>
                      {MARK[v]}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <span className="pt2-src">각 벤더의 공식 제품 문서와 기술 백서를 기준으로 정리했습니다</span>

        <p className="pt2-punch">
          무복호화는 이미 여럿이 합니다. 빈칸은 <b>판단 근거를 보여주는 능력</b>과
          <br />
          <b>현장 장비에 올릴 수 있는 가벼움</b>입니다.
        </p>

        <div className="pt2-why">
          <b>왜 아직 아무도 채우지 않았을까요</b>
          <p>
            무복호화 AI는 정확도를 올릴수록 내부가 블랙박스가 됩니다. 근거를 제시하지 못하는 경보는
            관제 현장에서 신뢰를 얻지 못했고 그래서 무거운 전용 장비와 복호화 방식이 계속 쓰였습니다.
            우리는 그 지점을 풀었습니다.
          </p>
        </div>
      </section>

      {/* 06 제로-클라 */}
      <section className="pt2-sec">
        <Head n="06" title="제로-클라" sub="그 빈칸을 그대로 채웁니다" />

        <div className="pt2-fill">
          <div className="pt2-fill-item">
            <span className="pt2-fill-axis">무복호화</span>
            <b>페이로드를 열지 않습니다</b>
            <p>헤더와 타이밍에서 얻은 플로우 통계만 사용하므로 통신 내용을 침해할 능력 자체가 없습니다.</p>
          </div>
          <div className="pt2-fill-item">
            <span className="pt2-fill-axis">판정 근거 설명</span>
            <b>어디를 보고 판단했는지 보여줍니다</b>
            <p>
              피처를 관계 행렬 이미지로 바꾸면 판정 근거를 히트맵으로 되돌릴 수 있습니다. 의료 시계열
              분석에서 검증된 이미지 변환 기법을 네트워크 트래픽으로 옮겨온 접근입니다.
            </p>
          </div>
          <div className="pt2-fill-item">
            <span className="pt2-fill-axis">경량 배포</span>
            <b>게이트웨이급 장비에서 돌아갑니다</b>
            <p>양자화와 경량화를 거쳐 고성능 GPU 없이도 실시간으로 동작합니다.</p>
          </div>
        </div>
      </section>

      {/* 07 매출 전망 */}
      <section className="pt2-sec">
        <Head n="07" title="매출 전망" sub="엔진을 공급하는 방식으로 진입합니다" />

        <div className="pt2-model">
          <b>완제품으로 정면 경쟁하지 않습니다</b>
          <p>
            관제 사업자와 보안 벤더에 탐지 엔진을 공급하고 클라우드 마켓플레이스에 등록하는 두 갈래로
            갑니다. 무복호화 분석 엔진을 완제품이 아니라 공급 형태로 판매하는 경로는 ipoque와 Qosmos
            같은 기업이 이미 검증한 방식입니다.
          </p>
        </div>

        <div className="pt2-formula">
          <div>
            <strong>{ASSUME.targetFirms}곳</strong>
            <span>1차 타겟 관제 사업자와 보안 벤더</span>
          </div>
          <i>×</i>
          <div>
            <strong>{ASSUME.unitPrice}억 원</strong>
            <span>연간 엔진 공급 계약 단가 가정</span>
          </div>
          <i>×</i>
          <div>
            <strong>확보율</strong>
            <span>연차별 확보 고객 수</span>
          </div>
        </div>

        <RevenueChart />
        <span className="pt2-src">
          국내 정보보안 사업체 {ASSUME.infoSecFirms}개사 가운데 관제와 네트워크 보안 사업자를 1차
          타겟으로 좁힌 가정값입니다. 단가와 확보율은 계약 조건에 따라 조정됩니다.
        </span>
      </section>
    </div>
  );
}
