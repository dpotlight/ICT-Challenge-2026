import type { FirewallRule, FlowDetail, FlowRow, Meta, SysInfo, Timeline, UploadSummary } from "../types";

async function j<T>(res: Response): Promise<T> {
  if (!res.ok) {
    let msg = `${res.status}`;
    try {
      const body = await res.json();
      msg = typeof body.detail === "string" ? body.detail : JSON.stringify(body.detail);
    } catch { /* noop */ }
    throw new Error(msg);
  }
  return res.json();
}

export const api = {
  meta: () => fetch("/api/meta").then((r) => j<Meta>(r)),
  system: () => fetch("/api/system").then((r) => j<SysInfo>(r)),
  timeline: (id: string, bins = 60) =>
    fetch(`/api/uploads/${id}/timeline?bins=${bins}`).then((r) => j<Timeline>(r)),

  uploadCsv: (file: File, profile = "auto") => {
    const fd = new FormData();
    fd.append("file", file);
    fd.append("profile", profile);
    return fetch("/api/uploads", { method: "POST", body: fd }).then((r) => j<UploadSummary>(r));
  },

  uploads: () => fetch("/api/uploads").then((r) => j<UploadSummary[]>(r)),
  upload: (id: string) => fetch(`/api/uploads/${id}`).then((r) => j<UploadSummary>(r)),
  deleteUpload: (id: string) =>
    fetch(`/api/uploads/${id}`, { method: "DELETE" }).then((r) => j<{ deleted: string }>(r)),

  flows: (id: string, offset: number, limit: number, classes: string[], sort = "row") =>
    fetch(`/api/uploads/${id}/flows?offset=${offset}&limit=${limit}&sort=${sort}${classes.length ? `&cls=${encodeURIComponent(classes.join(","))}` : ""}`)
      .then((r) => j<{ total: number; offset: number; rows: FlowRow[] }>(r)),

  similar: (id: string, row: number, k = 6) =>
    fetch(`/api/uploads/${id}/flows/${row}/similar?k=${k}`)
      .then((r) => j<{ rows: (FlowRow & { similarity: number })[] }>(r)),

  flow: (id: string, row: number) =>
    fetch(`/api/uploads/${id}/flows/${row}`).then((r) => j<FlowDetail>(r)),

  flowNav: (id: string, row: number, classes: string[]) =>
    fetch(`/api/uploads/${id}/flows/${row}/nav?only=all${classes.length ? `&cls=${encodeURIComponent(classes.join(","))}` : ""}`)
      .then((r) => j<{ prev: number | null; next: number | null; pos: number | null; total: number }>(r)),

  gradcamFeatures: (id: string, row: number, k = 5) =>
    fetch(`/api/uploads/${id}/flows/${row}/gradcam/features?k=${k}`)
      .then((r) => j<{ pairs: { pixel: [number, number]; feature_i: string; feature_j: string; score: number }[] }>(r)),

  imageUrl: (id: string, row: number) => `/api/uploads/${id}/flows/${row}/image.png`,
  gradcamUrl: (id: string, row: number) => `/api/uploads/${id}/flows/${row}/gradcam.png`,

  firewallRules: () => fetch("/api/firewall/rules").then((r) => j<{ rules: FirewallRule[] }>(r)),
  addRule: (upload_id: string, row_index: number) =>
    fetch("/api/firewall/rules", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ upload_id, row_index }),
    }).then((r) => j<{ created: number[] }>(r)),
  addAllAttacks: (upload_id: string) =>
    fetch("/api/firewall/rules", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ upload_id, all_attacks: true }),
    }).then((r) => j<{ created: number[]; duplicated: number[] }>(r)),
  deleteRule: (rule_id: string) =>
    fetch(`/api/firewall/rules/${rule_id}`, { method: "DELETE" }).then((r) => j<{ deleted: string }>(r)),
  clearRules: () =>
    fetch("/api/firewall/rules", { method: "DELETE" }).then((r) => j<{ deleted_count: number }>(r)),
  ruleImageUrl: (rule_id: string) => `/api/firewall/rules/${rule_id}/image.png`,
};
